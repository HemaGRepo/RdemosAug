#higher dimensional tables
# This demo uses a built in datset with name Titanic

#Titanic - this data has 4 dimensions, class, sex, age and survival

# margin.table(Titanic,1)  # count according to class
# margin.table(Titanic,4)  # count according to survival
# margin.table(Titanic)  # gives total count if index is not provided
barplot(margin.table(Titanic,4))
barplot(margin.table(Titanic,2))
