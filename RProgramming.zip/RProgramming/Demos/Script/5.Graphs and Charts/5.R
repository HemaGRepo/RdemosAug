# Pie chart

expenditure<-c("Housing"=600,"Food"=300,"Cloths"=150,"Shopping"=100,"Others"=90)
pie(expenditure)
pie(expenditure,
    labels=as.character(expenditure),
    main="Monthly Expenditure Breakdown",
    col=c("red","orange","yellow","blue","green"),
    border="brown",
    clockwise=TRUE
)
