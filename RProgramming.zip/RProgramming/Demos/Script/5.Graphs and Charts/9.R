# Functions to generate Binomial distribution

#The binomial distribution model deals with finding the probability of success of an event
#which has only two possible outcomes in a series of experiments.
#For example, tossing of a coin always gives a head or a tail. 
#The probability of finding exactly 3 heads in tossing a coin repeatedly for 10 times 
#is estimated during the binomial distribution.

# Create a sample of 50 numbers which are incremented by 1.
x <- seq(0,50,by = 1)

# Create the binomial distribution.
y <- dbinom(x,50,0.5)

plot(x,y)

# Probability of getting 26 or less heads from a 51 tosses of a coin.
x <- pbinom(26,51,0.5)

print(x)

# How many heads will have a probability of 0.25 will come out when a coin is tossed 51 times.
x <- qbinom(0.25,51,1/2)

print(x)

# Find 8 random values from a sample of 150 with probability of 0.4.
x <- rbinom(8,150,.4)

print(x)