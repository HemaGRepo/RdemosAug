rnorm(10) # draws 10 random numbers from a standard normal distribution
rnorm(10, 5, 2) # draws 10 random numbers from a N(� = 5,?? = 2) distribution
pnorm(0) # returns the value of a standard normal cdf at t = 0
qnorm(0.5) # returns the 50% quantile of the standard normal distribution

#Assume that we want to generate 50 (standard) normally distributed random
#numbers and to display them as a histogram. Additionally, we want to add the
#pdf of the ("fitted") normal distribution to the plot a

mysample <- rnorm(50) # generates random numbers
hist(mysample, prob = TRUE) # draws the histogram 
mu <- mean(mysample) # computes the sample mean
sigma <- sd(mysample) # computes the sample standard deviation 
x <- seq(-4, 4, length = 500) # defines x-values for the pdf
y <- dnorm(x, mu, sigma) # computes the normal pdf
lines(x, y) # adds the pdf as "lines" to the plot

x <- 0:50 # defines the x-values
y <- dbinom(x, 50, 0.25) # computes the binomial
probabilities
plot(x, y, type="h") # plots binomial probabilities
x2 <- seq(0, 50, length = 500)# defines x-values (for the
normal pdf)
y2 <- dnorm(x2, 50*0.25,
            sqrt(50*0.25*(1-0.25))) # computes the normal pdf
lines(x2, y2, col = "red") # draws the normal pdf