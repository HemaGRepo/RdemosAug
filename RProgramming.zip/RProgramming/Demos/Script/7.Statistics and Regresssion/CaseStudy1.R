#Regression Analysis

# Linear Regression Analysis
# A random sampling is done in the paddy fields and the produce in each filed is measured
# The fields are of varied size ie. Hectares and the tonnes of produce is availabe as follows

fieldSize<-c(3.4,8.6,2.9,10,12,1.5,8.1,9.8)
produce<-c(18,64,16,98,96,10,60,70)

relation <- lm(produce~fieldSize)
print(relation)

newField<-data.frame(fieldSize=7.4)
result<-predict(relation,newField)
print(result)

# Plot a graph for the field size and produce

plot(produce,fieldSize,col = "green",main = "Produce - Hectare regression",
     abline(lm(fieldSize~produce)),cex = 1.3,pch = 16,xlab = "Size in Hectares",ylab = "Produce in Tonnes")

