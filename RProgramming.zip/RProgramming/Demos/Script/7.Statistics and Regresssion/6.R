#Logistic Regression
#Type of questions that a logistics regression can examine.
#How does the probability of getting lung cancer (yes vs. no) change for every additional pound of overweight and for every pack of cigarettes smoked per day?
#Do body weight calorie intake, fat intake, and participant age have an influence on heart attacks (yes vs. no)?
# Select some columns form mtcars.am represents automatic or manual
input <- mtcars[,c("am","cyl","hp","wt")]
print(input)

am.data = glm(formula = am ~ cyl + hp + wt, data = input, family = binomial)

print(summary(am.data))

#In the summary as the p-value in the last column is more than 0.05 for the variables "cyl" and "hp",
#we consider them to be insignificant in contributing to the value of the variable "am".
#Only weight (wt) impacts the "am" value in this regression model.
