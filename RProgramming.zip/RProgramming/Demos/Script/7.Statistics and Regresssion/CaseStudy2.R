# Government provides subsidy to every family based on the following parameters
#Annual Income, No of members, Number employed
# Create a Multiple regression analysis to calculate the subsidy for families given the above data

# Create the data frame.
family.data <- data.frame(
  income=c(25000,32000,12000,46000,60000,10000,30000),
  members=c(4,3,8,2,8,3,5),
  employed=c(2,2,1,1,3,2,1),
  subsidy=c(12000,10000,25000,5000,8000,12000,18000)
)
# Print the summary.
print(family.data)

# Create the relationship model.
model <- lm(subsidy~income+members+employed, data = family.data)

# Show the model.
print(model)

# Get the Intercept and coefficients as vector elements.
cat("# # # # The Coefficient Values # # # ","\n")

a <- coef(model)[1]
print(a)

XIncome <- coef(model)[2]
XMembers <- coef(model)[3]
XEmployed <- coef(model)[4]

print(XIncome)
print(XMembers)
print(XEmployed)

#Based on the above intercept and coefficient values, we create the mathematical equation.
#Y =  16302.84+(-0.2203737)*x1+(1937.825)*x2+(-3390.649)*x3
#For a family with income=22000, members=5 and employed=2, the subsidy is calculated as

#Y =  16302.84+(-0.2203737)*22000+(1937.825)*5+(-3390.649)*2
print(16302.84+(-0.2203737)*22000+(1937.825)*5+(-3390.649)*2)
