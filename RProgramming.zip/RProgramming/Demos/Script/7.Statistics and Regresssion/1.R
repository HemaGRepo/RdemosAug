#Finding Mean mean(x, trim = 0, na.rm = FALSE, ...)

# Create a vector. 
x <- c(12,7,3,4.2,18,2,54,-21,8,-5)

# Find Mean.
result.mean <- mean(x)
print(result.mean)


# Create a vector.
x <- c(12,7,3,4.2,18,2,54,-21,8,-5)
#When trim = 0.3,the vector is sorted and  3 values from each end will be dropped from the calculations to find mean.

# Find Mean.
result.mean <-  mean(x,trim = 0.3)
print(result.mean)

# Create a vector. 
x <- c(12,7,3,4.2,18,2,54,-21,8,-5,NA)

# Find mean.
result.mean <-  mean(x)
print(result.mean)

# Find mean dropping NA values.
result.mean <-  mean(x,na.rm = TRUE)
print(result.mean)
