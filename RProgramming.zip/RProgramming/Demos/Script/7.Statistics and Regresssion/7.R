# Create a sequence of numbers between -10 and 10 incrementing by 0.1.
x <- seq(-10, 10, by = .1)
#dnorm - This function gives height of the probability distribution at each point for a given mean and standard deviation.
# Choose the mean as 2.5 and standard deviation as 0.5.
y <- dnorm(x, mean = 2.5, sd = 0.5)

# Give the chart file a name.
#png(file = "dnorm.png")

plot(x,y)

# Save the file.
#dev.off()