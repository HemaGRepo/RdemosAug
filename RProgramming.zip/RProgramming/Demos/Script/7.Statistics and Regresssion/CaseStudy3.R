#Do body weight, calorie intake, fat intake, and participant age have an influence on heart attacks (yes vs. no)?

# Create the data frame.
health.data1 <- data.frame(
  heartDisease=c(0,0,0,1,1,1,0,0),
  bodyweight=c(96,63,84,90,82,55,73,66),
  calorie=c(2345,3444,1000,5676,1389,2111,1989,2898),
  fat=c(77,64,34,62,59,62,90,62),
  age=c(55,40,42,63,59,31,58,71)
)

health.data <- data.frame(
  heartDisease=c(1,0),
  bodyweight=c(96,63),
  calorie=c(2345,3444),
  fat=c(77,64),
  age=c(55,40)
)
print(health.data)
hd.data = glm(formula = heartDisease~bodyweight+calorie+fat+age, data = health.data, family = binomial)

print(summary(hd.data))

smoking.data<-data.frame(
  age=c(77,65,54,89,72,81,74,82,91,55,70),
  smoking=c(10,14,5,8,9,2,7,8,9,8,10),
  outcome=c(0,1,0,1,1,0,0,0,1,1,0),
  bodyweight=c(66,93,84,98,89,55,73,66,99,92,77)
)

print(smoking.data)
s.data = glm(formula = outcome~age+smoking+bodyweight, data = smoking.data, family = binomial)

print(summary(s.data))

