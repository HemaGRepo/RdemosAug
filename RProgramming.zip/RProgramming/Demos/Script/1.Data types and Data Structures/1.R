myString <- "Hello, World!"
print (myString)
print (class(myString))

