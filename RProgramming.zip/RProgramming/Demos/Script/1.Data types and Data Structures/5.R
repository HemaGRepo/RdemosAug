# Create a list.
list1 <- list(c(2,5,3),21.3,sin)

# Print the list.
print(list1)