# Create an array.
a <- array(c('green','yellow'),dim = c(3,3,2))
print(a)

a <- array(c('green','yellow'),dim = c(3,2,3))
print(a)