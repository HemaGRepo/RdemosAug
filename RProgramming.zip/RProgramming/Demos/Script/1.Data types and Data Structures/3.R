#Datatypes
#Logical

v <- 23.5 
print (class(v))

#Numeric

v1 <- 23.5
print (class(v1))

#Integer

v2 <- 2L
print (class(v2))

#Complex

v3 <- 2+5i
print (class(v3))

#Character

v4 <- "TRUE"
print(class(v4))


# Create a vector.
apple <- c('red','green',"yellow")
print (apple)

# Get the class of the vector.
print (class(apple))




