#Numeric

v5<-charToRaw("Hello")
print(class(v5))


