#for Loop

v <- LETTERS[1:4]
for ( i in v) {
  print(i)
}

v1 <- 1:5
for ( j in v1) {
  print(j)
}
