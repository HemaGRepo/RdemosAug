# to find all the variables declared till now
print(ls())

# List the variables starting with the pattern "var".
print(ls(pattern = "var")) 

# List the variables starting with the pattern "var".
print(ls(pattern = ".1"))   

#The variables starting with dot(.) are hidden, they can be listed using "all.names = TRUE" argument to ls() function.
print(ls(all.name = TRUE))

#Delete a variable using rm
rm(var.3)

# Delete all variables using rm and ls
rm(list = ls())