#Lazy Evaluation of Function
#Arguments to functions are evaluated lazily, which means so they are evaluated only when needed by the function body.
# Create a function with arguments.
new.function <- function(a, b) {
  print(a^2)
  print(a)
  print(b)
}

# Evaluate the function without supplying one of the arguments.
new.function(6)
