# Recursive function to find factorial of
# natural numbers upto n
# using recursive function

recursive.factorial <- function(x) {
  if (x == 0)    return (1)
  else           return (x * recursive.factorial(x-1))
}