#Function with return
check <- function(x) {
  if (x>0) {
    return("Positive")
  }
  else if (x<0) {
    return("Negative")
  }
  else {
    return("Zero")
  }
}
check(1)
check(-10)
check(0)
