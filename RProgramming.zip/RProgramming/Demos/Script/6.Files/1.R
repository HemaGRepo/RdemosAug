#READING AND WRITING DATA - CSV FILE
# Create a data frame.
data <- read.csv("input.csv")
print(data)


# Get the max salary from data frame.
sal <- max(data$salary)
print(sal)

retval <- subset(data, salary == max(salary))
print(retval)

retval <- subset( data, dept == "IT")
print(retval)

retval <- subset(data, as.Date(start_date) > as.Date("2014-01-01"))
print(retval)

retval <- subset(data, as.Date(start_date) > as.Date("2014-01-01"))

# Write filtered data into a new file.
write.csv(retval,"output.csv")
newdata <- read.csv("output.csv")
print(newdata)