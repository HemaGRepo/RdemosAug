check <- function(x) {
  data <- read.csv("input.csv")
  retval <- subset(data, as.Date(start_date) > as.Date(x))
  print(retval)
}