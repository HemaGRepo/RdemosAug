#Connecting to Database - Oracle
install.packages("RODBC")
library(RODBC)

# Go to Control Panel -> Administrative Tools ->ODBC and create a new DSN

#DSN Created is newDb

channel <- odbcConnect("newDb", uid="hema", pwd="hema676412", believeNRows=FALSE)
odbcGetInfo(channel)

dataframe<-sqlQuery(channel,"SELECT * FROM hema.employees")
print(dataframe)

t<-sqlQuery(channel,"SELECT * FROM hema.temperature")
print(t)
pie(t$TEMP,t$CITY)