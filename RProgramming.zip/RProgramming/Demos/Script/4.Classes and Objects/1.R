# create a list with required components
s <- list(name = "John", age = 21, GPA = 3.5)
 # name the class appropriately
class(s) <- "student"
print(s)